from __future__ import absolute_import
from __future__ import print_function

import os
import sys
from sumolib import checkBinary  
import traci
from TrafficGenerator import generate_routefile
from modify_phase import modify_phase
from del_lane import del_lane
from performance import calculate_target_index

# $SUMO_HOME/tools directory에서 python module 가져와야 실행 가능
if 'SUMO_HOME' in os.environ:
    tools = os.path.join(os.environ['SUMO_HOME'], 'tools')
    sys.path.append(tools)
else:
    sys.exit("please declare environment variable 'SUMO_HOME'")


def run():
    step = 0
    max_step = 3600
    cycle_list = []
    vehicle_travel_times = {}
    del_lane()
    
    while step < max_step+1:
        traci.simulationStep()
        if step > 1800:
            target_score = calculate_target_index()
            cycle_list.append(target_score)
            cycle_average = sum(cycle_list) / len(cycle_list)

            vehicle_ids = traci.vehicle.getIDList()
            for vehicle_id in vehicle_ids:
                if vehicle_id not in vehicle_travel_times:
                    vehicle_travel_times[vehicle_id] = 0
                vehicle_travel_times[vehicle_id] += 1
            average_travel_time_list = list(vehicle_travel_times.values())
            average_travel_time = sum(average_travel_time_list) / len(average_travel_time_list)

            if step % 180 == 0:
                print("{}초 평균 대기 시간 : {:.2f}".format(step, cycle_average))
                print("{}초 총 이탈 차량 수 : {}, 평균 이동 시간 : {}".format(step, len(vehicle_travel_times), average_travel_time))
        step += 1
    print("평균 대기 시간 : {:.3f}".format(cycle_average))
    print("평균 이동 시간 : {:.3f}".format(average_travel_time))
    traci.close()

def main():
    # 초기 신호 설정값
    current_phases0 = [31.00, 3.00, 17.00, 3.00, 27.00, 3.00, 38.00, 3.00, 52.00, 3.00]
    current_phases1 = [33.00, 3.00, 17.00, 3.00, 22.00, 3.00, 32.00, 3.00, 61.00, 3.00]
    current_phases2 = [25.00, 3.00, 47.00, 3.00, 18.00, 3.00, 51.00, 3.00, 24.00, 3.00]
    
    # 13번신호 설정값    
    # current_phases0 = [26.00, 3.00, 17.00, 3.00, 27.00, 3.00, 43.00, 3.00, 52.00, 3.00]
    # current_phases1 = [26.00, 3.00, 17.00, 3.00, 22.00, 3.00, 39.00, 3.00, 61.00, 3.00]
    # current_phases2 = [22.00, 3.00, 42.00, 3.00, 21.00, 3.00, 56.00, 3.00, 24.00, 3.00]

    # 진환 신호 설정값    
    # current_phases0 = [26.00, 3.00, 17.00, 3.00, 27.00, 3.00, 43.00, 3.00, 52.00, 3.00]
    # current_phases1 = [22.00, 3.00, 17.00, 3.00, 20.00, 3.00, 45.00, 3.00, 61.00, 3.00]
    # current_phases2 = [25.00, 3.00, 44.00, 3.00, 21.00, 3.00, 60.00, 3.00, 20.00, 3.00]

    # PSO
    current_phases0 = [21, 3, 21, 3, 21, 3, 47, 3, 55, 3]
    current_phases1 = [42, 3, 11, 3, 24, 3, 21, 3, 67, 3]
    current_phases2 = [17, 3, 38, 3, 24, 3, 62, 3, 24, 3]

    options = True
    if options == False:
        sumoBinary = checkBinary('sumo')
    else:
        sumoBinary = checkBinary('sumo-gui')

    traci.start([sumoBinary, "-c", "new.sumocfg", "--tripinfo-output", "tripinfo.xml", "--quit-on-end", "--no-warnings"])
    # traci.start([sumoBinary, "-c", "new.sumocfg", "--tripinfo-output", "tripinfo.xml", "--quit-on-end","--start", "--no-warnings"])
    generate_routefile() 
    modify_phase(current_phases0, current_phases1, current_phases2)
    run()

if __name__ == "__main__":
    main()
